/* Partyリスト初期化 */
var initPartySelector = function(elem) {
  $(elem).append('<option value="CN=CST,O=TKK Heavy Industries Ltd,L=Tokyo,C=JP">TKK Heavy Industries Ltd.</option>');
  $(elem).append('<option value="CN=CST,O=YMT Corp,L=SS,C=US">YMT Corp.</option>');
  $(elem).append('<option value="CN=TRC,O=ABC Trading Company Corp,L=Nagoya,C=JP">ABC Trading Company Inc.</option>');
  $(elem).append('<option value="CN=TRC,O=XYZ Trading Company Corp,L=Georgetown,C=US">XYZ Trading Company Inc.</option>');
  $(elem).append('<option value="CN=SUP,O=TKD Plant Ltd,L=Tokyo,C=JP">TKD Plant Ltd.</option>');
  $(elem).append('<option value="CN=SUP,O=GG Planning Ltd,L=LA,C=US">GG Planning Ltd.</option>');
  $(elem).append('<option value="CN=WH,O=Warehouse Alice,L=Seatle,C=US">Warehouse Alice</option>');
  $(elem).append('<option value="CN=WH,O=Soko Bob,L=Osaka,C=JP">Soko Bob</option>');
}

/* 単位(金額)リスト初期化 */
var initUnitOfAmountSelector = function(elem) {
  $(elem).append('<option value="CNY">CNY</option>');
  $(elem).append('<option value="EUR">EUR</option>');
  $(elem).append('<option value="GBP">GBP</option>');
  $(elem).append('<option value="INR">INR</option>');
  $(elem).append('<option value="JPY">JPY</option>');
  $(elem).append('<option value="KRW">KRW</option>');
  $(elem).append('<option value="PHP">PHP</option>');
  $(elem).append('<option value="RUB">RUB</option>');
  $(elem).append('<option value="SGD">SGD</option>');
  $(elem).append('<option value="THB">THB</option>');
  $(elem).append('<option value="USD">USD</option>');
}

/* 単位(数量)リスト初期化 */
var initUnitOfQuantitySelector = function(elem) {
  $(elem).append('<option value="g">g</option>');
  $(elem).append('<option value="kg">kg</option>');
  $(elem).append('<option value="t">t</option>');
  $(elem).append('<option value="oz">oz</option>');
  $(elem).append('<option value="lb">lb</option>');
  $(elem).append('<option value="mm">mm</option>');
  $(elem).append('<option value="cm">cm</option>');
  $(elem).append('<option value="m">m</option>');
  $(elem).append('<option value="km">km</option>');
  $(elem).append('<option value="in">in</option>');
  $(elem).append('<option value="ft">ft</option>');
  $(elem).append('<option value="mile">mile</option>');
  $(elem).append('<option value="piece">piece</option>');
  $(elem).append('<option value="set">set</option>');
}

/* 受注ステータスリスト初期化 */
var initNameOfTrcReceiptOrderStatusSelector = function(elem) {
  $(elem).append('<option value="10">10:UnShipped</option>');
  $(elem).append('<option value="20">20:Shipping</option>');
  $(elem).append('<option value="30">30:Receiving</option>');
  $(elem).append('<option value="40">40:Received</option>');
  $(elem).append('<option value="50">50:Demanding</option>');
  $(elem).append('<option value="ZZ">ZZ:Complete</option>');
}

/* 発注ステータスリスト初期化 */
var initNameOfTrcPlacingOrderStatusSelector = function(elem) {
  $(elem).append('<option value="10">10:Ordered</option>');
  $(elem).append('<option value="20">20:Delivering</option>');
  $(elem).append('<option value="30">30:Delivered</option>');
  $(elem).append('<option value="40">40:Demanding</option>');
  $(elem).append('<option value="ZZ">ZZ:Complete</option>');
}

