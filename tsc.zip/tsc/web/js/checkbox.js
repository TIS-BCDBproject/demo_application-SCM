
/* 一括選択のチェックボックスが変化した場合 */
function checkAll(tableId,chk) {
  var tableObj = document.getElementById(tableId);
  for (var i = 1; i < tableObj.rows.length; i++) {
    tableObj.rows[i].cells[0].firstChild.checked = chk;
  }
}

/* 個別のチェックボックスが変化した場合 */
function disCheckAll() {
  var tableObjCn = document.getElementsByClassName("table table-bordered auxiliary-table floatThead-table");
  tableObjCn[0].rows[0].cells[0].firstChild.checked = false;
}
