var baseUrl = "http://localhost:10016";
var baseApiUrl = baseUrl + "/api";
var baseCustomerUrl = "http://localhost:10008";
var baseCustomerApiUrl = baseCustomerUrl + "/api";
var baseWarehouseUrl = "http://localhost:10032";
var baseWarehouseApiUrl = baseWarehouseUrl + "/api";
var baseSupplierUrl = "http://localhost:10024";
var baseSupplierApiUrl = baseSupplierUrl + "/api";

var baseXyzApiUrl = "http://localhost:10020" + "/api";
var baseBobApiUrl = "http://localhost:10036" + "/api";
var baseYMTApiUrl = "http://localhost:10012" + "/api";
var baseGGApiUrl = "http://localhost:10028" + "/api";

